<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TypePaymentController extends Controller
{
    //
}
